from distutils.core import setup
setup(name='pure',version='1.0.2',description='芷琦哥的回测框架',author='陈宗伟',py_modules=['pure_evening_breeze'])